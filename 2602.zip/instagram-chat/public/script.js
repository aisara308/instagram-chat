const socket = io();
const userId = `user_${Math.floor(Math.random() * 10000)}`;
const profilePic = "C:/Users/HP/Downloads/inst.jpg";

document.getElementById('send-btn').addEventListener('click', () => {
    const input = document.getElementById('message-input');
    const message = input.value.trim();
    if (message) {
        socket.emit('chat message', { userId, profilePic, msg: message });
        input.value = '';
    }
});

socket.on('chat message', (data) => {
    appendMessage(data);
});

function appendMessage(data) {
    const li = document.createElement('li');
    li.innerHTML = `<img src="${data.profilePic}" class="msg-pic"> <strong>${data.userId}:</strong> <span>${data.msg}</span>`;
    document.getElementById('messages').appendChild(li);
}
