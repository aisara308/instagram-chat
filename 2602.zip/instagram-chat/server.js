const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const fs = require('fs');

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const chatHistoryFile = 'chatHistory.json';

app.use(express.static('public'));
const loadChatHistory = () => {
    if (fs.existsSync(chatHistoryFile)) {
        return JSON.parse(fs.readFileSync(chatHistoryFile));
    }
    return [];
};
const saveChatHistory = (messages) => {
    fs.writeFileSync(chatHistoryFile, JSON.stringify(messages, null, 2));
};

let chatHistory = loadChatHistory();

io.on('connection', (socket) => {
    console.log('Пайдаланушы қосылды');
    socket.emit('chat history', chatHistory);
    
    socket.on('chat message', ({ userId, msg }) => {
        const timestamp = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
        const messageData = { userId, text: msg, time: timestamp };
        chatHistory.push(messageData);
        saveChatHistory(chatHistory);
        io.emit('chat message', messageData);
    });

    socket.on('disconnect', () => {
        console.log('Пайдаланушы ажыратылды');
    });
});

server.listen(3000, () => {
    console.log('Server: http://localhost:3000');
});
